def classFactory(iface):
    from .main import styx4d_DL_plugin
    return styx4d_DL_plugin(iface)